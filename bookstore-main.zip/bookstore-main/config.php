<?php
$conn = mysqli_connect('localhost','root','','books') or die('connection failed');
?>